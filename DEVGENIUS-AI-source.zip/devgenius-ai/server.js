require("dotenv").config();

const express = require("express");
const path = require("path");
const rateLimit = require("express-rate-limit");
const OpenAI = require("openai");

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const MODEL = process.env.OPENAI_MODEL || "gpt-4.1-mini";
const MAX_INPUT = 30000;

app.disable("x-powered-by");
app.use(express.json({ limit: "100kb" }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/api/", rateLimit({
  windowMs: 60 * 1000,
  limit: 20,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "ส่งคำขอบ่อยเกินไป กรุณารอสักครู่แล้วลองใหม่" }
}));

const client = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

const SYSTEM = `คุณคือ DEVGENIUS AI ผู้ช่วยวิศวกรซอฟต์แวร์ที่รอบคอบ
ตอบเป็นภาษาเดียวกับผู้ใช้เป็นหลัก
เมื่อเขียนหรือแก้โค้ด:
- ส่งโค้ดที่ครบถ้วน ใช้งานได้ และระบุชื่อไฟล์เมื่อเกี่ยวข้อง
- ตรวจ syntax, edge cases, input validation, security และ error handling
- อย่าอ้างว่าทดสอบโค้ดแล้ว หากไม่ได้รันทดสอบจริง
- หากข้อมูลไม่พอ ให้ถามเฉพาะสิ่งที่จำเป็น หรือระบุสมมติฐาน
- อธิบายสาเหตุของบั๊กและสรุปสิ่งที่เปลี่ยน
- ห้ามเปิดเผย API keys, secrets หรือข้อมูลลับที่พบในโค้ด
- อย่าใส่ markdown code fence ครอบคำตอบทั้งหมด เว้นแต่ผู้ใช้ขอ`;

function requireAI(req, res, next) {
  if (!client) {
    return res.status(503).json({
      error: "ยังไม่ได้ตั้งค่า OPENAI_API_KEY กรุณาคัดลอก .env.example เป็น .env แล้วใส่ API key"
    });
  }
  next();
}

function readText(value, field) {
  if (typeof value !== "string" || !value.trim()) {
    throw new Error(`กรุณาระบุ ${field}`);
  }
  if (value.length > MAX_INPUT) {
    throw new Error(`${field} ยาวเกิน ${MAX_INPUT} ตัวอักษร`);
  }
  return value.trim();
}

async function askAI(messages) {
  const response = await client.chat.completions.create({
    model: MODEL,
    messages,
    temperature: 0.2
  });
  return response.choices?.[0]?.message?.content?.trim() || "AI ไม่ได้ส่งข้อความตอบกลับ";
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(client), model: MODEL });
});

app.post("/api/chat", requireAI, async (req, res) => {
  try {
    const prompt = readText(req.body?.prompt, "ข้อความ");
    const code = typeof req.body?.code === "string" ? req.body.code.slice(0, MAX_INPUT) : "";
    const answer = await askAI([
      { role: "system", content: SYSTEM },
      { role: "user", content: code ? `${prompt}\n\nโค้ดประกอบ:\n${code}` : prompt }
    ]);
    res.json({ answer });
  } catch (err) {
    res.status(err.message.startsWith("กรุณา") || err.message.includes("ยาวเกิน") ? 400 : 500)
      .json({ error: err.message || "เกิดข้อผิดพลาดในการประมวลผล" });
  }
});

app.post("/api/review", requireAI, async (req, res) => {
  try {
    const code = readText(req.body?.code, "โค้ด");
    const language = String(req.body?.language || "ไม่ระบุ").slice(0, 80);
    const answer = await askAI([
      { role: "system", content: SYSTEM },
      { role: "user", content: `ตรวจสอบโค้ดภาษา ${language} นี้อย่างละเอียด
จัดผลลัพธ์เป็น: 1) ภาพรวม 2) บั๊ก/ความเสี่ยงพร้อมตำแหน่งถ้าระบุได้ 3) ประเด็นความปลอดภัย 4) แนวทางปรับปรุง
หากไม่พบประเด็น ให้บอกว่าเป็นการตรวจจากการอ่าน ไม่ใช่การรับรองว่าไร้บั๊ก\n\n${code}` }
    ]);
    res.json({ answer });
  } catch (err) {
    res.status(400).json({ error: err.message || "ตรวจสอบโค้ดไม่สำเร็จ" });
  }
});

app.post("/api/fix", requireAI, async (req, res) => {
  try {
    const code = readText(req.body?.code, "โค้ด");
    const issue = typeof req.body?.issue === "string" ? req.body.issue.slice(0, 5000) : "";
    const language = String(req.body?.language || "ไม่ระบุ").slice(0, 80);
    const answer = await askAI([
      { role: "system", content: SYSTEM },
      { role: "user", content: `ช่วยหาสาเหตุและแก้บั๊กในโค้ดภาษา ${language}
อาการ/ข้อความ error (ถ้ามี): ${issue || "ไม่ได้ระบุ"}
โปรดแสดง 1) สาเหตุที่เป็นไปได้ 2) โค้ดฉบับแก้ไขแบบครบถ้วนใน code fence ที่ระบุภาษา 3) วิธีทดสอบหลังแก้
อย่าคาดเดาว่ารันผ่านแล้ว\n\nโค้ด:\n${code}` }
    ]);
    res.json({ answer });
  } catch (err) {
    res.status(400).json({ error: err.message || "แก้ไขโค้ดไม่สำเร็จ" });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, "0.0.0.0", () => {
  console.log(`DEVGENIUS AI พร้อมใช้งานที่ http://localhost:${PORT}`);
  if (!client) console.log("ยังไม่ได้ตั้งค่า OPENAI_API_KEY — เพิ่มในไฟล์ .env ก่อนใช้งาน AI");
});