const $ = (id) => document.getElementById(id);
const code = $("code");
let toastTimer;

function toast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2800);
}
function updateEditorMeta() {
  const lines = Math.max(1, code.value.split("\n").length);
  $("line-numbers").textContent = Array.from({length: lines}, (_, i) => i + 1).join("\n");
  $("char-count").textContent = `${code.value.length.toLocaleString()} characters`;
}
code.addEventListener("input", updateEditorMeta);
code.addEventListener("scroll", () => { $("line-numbers").scrollTop = code.scrollTop; });

async function api(path, body) {
  const response = await fetch(path, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(body)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}
function renderText(target, text) {
  target.classList.remove("empty");
  target.replaceChildren();
  // Render plain text safely; never inject AI output as HTML.
  const pre = document.createElement("div");
  pre.textContent = text;
  pre.style.whiteSpace = "pre-wrap";
  pre.style.lineHeight = "1.75";
  pre.style.overflowWrap = "anywhere";
  target.appendChild(pre);
}
function setBusy(button, busy, label) {
  if (busy) {
    button.dataset.original = button.innerHTML;
    button.disabled = true;
    button.textContent = label || "กำลังประมวลผล…";
  } else {
    button.disabled = false;
    if (button.dataset.original) button.innerHTML = button.dataset.original;
  }
}
async function runTool(kind, button) {
  if (!code.value.trim()) return toast("กรุณาใส่โค้ดก่อน");
  const lang = $("language").value;
  const output = $("output");
  setBusy(button, true, "AI กำลังวิเคราะห์…");
  output.textContent = "กำลังส่งโค้ดให้ AI วิเคราะห์ กรุณารอสักครู่…";
  output.classList.remove("empty");
  try {
    let result;
    if (kind === "review") result = await api("/api/review", {code: code.value, language: lang});
    if (kind === "fix") result = await api("/api/fix", {code: code.value, language: lang, issue: $("issue").value});
    if (kind === "explain") result = await api("/api/chat", {prompt: `อธิบายโค้ดภาษา ${lang} นี้เป็นภาษาไทยอย่างเป็นขั้นตอน พร้อมอธิบายการทำงานของส่วนสำคัญ`, code: code.value});
    renderText(output, result.answer);
  } catch (error) {
    renderText(output, `เกิดข้อผิดพลาด: ${error.message}`);
  } finally { setBusy(button, false); }
}
$("review-btn").addEventListener("click", e => runTool("review", e.currentTarget));
$("fix-btn").addEventListener("click", e => runTool("fix", e.currentTarget));
$("explain-btn").addEventListener("click", e => runTool("explain", e.currentTarget));
$("copy-btn").addEventListener("click", async () => {
  try { await navigator.clipboard.writeText(code.value); toast("คัดลอกโค้ดแล้ว"); }
  catch { toast("ไม่สามารถคัดลอกได้ในเบราว์เซอร์นี้"); }
});
$("copy-output").addEventListener("click", async () => {
  try { await navigator.clipboard.writeText($("output").innerText); toast("คัดลอกผลลัพธ์แล้ว"); }
  catch { toast("ไม่มีผลลัพธ์ให้คัดลอก"); }
});
$("download-btn").addEventListener("click", () => {
  const ext = ({JavaScript:"js",TypeScript:"ts",Python:"py",HTML:"html",CSS:"css",Java:"java","C++":"cpp"})[$("language").value] || "txt";
  const blob = new Blob([code.value], {type:"text/plain;charset=utf-8"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = `devgenius-code.${ext}`; a.click();
  URL.revokeObjectURL(url);
});
$("clear-btn").addEventListener("click", () => {
  if (code.value && !confirm("ล้างโค้ดทั้งหมดใช่ไหม?")) return;
  code.value = ""; updateEditorMeta(); toast("ล้างโค้ดแล้ว");
});

document.querySelectorAll(".nav-item").forEach(button => button.addEventListener("click", () => {
  const chat = button.dataset.tab === "chat";
  $("editor-view").classList.toggle("hidden", chat);
  $("chat-view").classList.toggle("hidden", !chat);
  $("page-title").textContent = chat ? "AI Assistant" : "Code Studio";
  document.querySelectorAll(".nav-item").forEach(item => item.classList.toggle("active", item === button));
}));

$("chat-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const prompt = $("chat-input").value.trim();
  if (!prompt) return;
  const messages = $("chat-messages");
  const user = document.createElement("div");
  user.className = "message user";
  const userName = document.createElement("b"); userName.textContent = "YOU";
  const userText = document.createElement("p"); userText.textContent = prompt;
  user.append(userName, userText); messages.appendChild(user);
  $("chat-input").value = "";
  const send = event.submitter || $("chat-form").querySelector("button");
  setBusy(send, true, "กำลังคิด…");
  const pending = document.createElement("div");
  pending.className = "message assistant";
  pending.textContent = "DEVGENIUS AI กำลังคิดคำตอบ…";
  messages.appendChild(pending); messages.scrollTop = messages.scrollHeight;
  try {
    const withCode = $("include-code").checked && code.value.trim();
    const result = await api("/api/chat", {prompt, code: withCode ? code.value : ""});
    pending.textContent = result.answer;
  } catch (error) {
    pending.textContent = `เกิดข้อผิดพลาด: ${error.message}`;
  } finally {
    setBusy(send, false); messages.scrollTop = messages.scrollHeight;
  }
});

async function checkHealth() {
  try {
    const response = await fetch("/api/health");
    const data = await response.json();
    $("connection-title").textContent = data.configured ? "AI พร้อมใช้งาน" : "รอตั้งค่า API Key";
    $("connection-detail").textContent = data.configured ? `Model: ${data.model}` : "เพิ่ม OPENAI_API_KEY ใน .env";
    document.querySelector(".status-dot").style.background = data.configured ? "var(--green)" : "#e0ae54";
  } catch {
    $("connection-title").textContent = "เชื่อมต่อเซิร์ฟเวอร์ไม่ได้";
    $("connection-detail").textContent = "ตรวจสอบการทำงานของเซิร์ฟเวอร์";
  }
}
updateEditorMeta();
checkHealth();