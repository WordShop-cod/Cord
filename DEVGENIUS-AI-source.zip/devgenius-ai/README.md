# DEVGENIUS AI

เว็บ AI Coding Assistant ธีม Dark มีเครื่องมือ:
- Code Studio สำหรับวาง/เขียนโค้ด เลือกภาษา คัดลอก และดาวน์โหลด
- AI Assistant สำหรับถามคำถามเกี่ยวกับการเขียนโปรแกรม
- ตรวจโค้ดเพื่อหาบั๊ก ความเสี่ยง และประเด็นด้านความปลอดภัย
- ช่วยวิเคราะห์และเสนอการแก้ไขบั๊ก
- อธิบายโค้ด

> ไม่มี AI ตัวใดรับประกันโค้ดไร้บั๊ก 100% ควรตรวจทานและรันทดสอบก่อนใช้งานจริง

## สิ่งที่ต้องมี
- Node.js 18 ขึ้นไป
- API key จากผู้ให้บริการที่รองรับ OpenAI API

## วิธีติดตั้ง
1. แตกไฟล์ ZIP
2. เปิด Terminal ในโฟลเดอร์ `devgenius-ai`
3. ติดตั้ง dependencies:

   ```bash
   npm install
   ```

4. คัดลอก `.env.example` เป็น `.env`
   - macOS/Linux: `cp .env.example .env`
   - Windows PowerShell: `Copy-Item .env.example .env`

5. เปิด `.env` แล้วใส่ API key ของคุณใน `OPENAI_API_KEY`
6. เริ่มระบบ:

   ```bash
   npm start
   ```

7. เปิดเบราว์เซอร์ที่ http://localhost:3000

## ตั้งค่าโมเดล
เปลี่ยน `OPENAI_MODEL` ใน `.env` เป็นชื่อโมเดลที่บัญชี API ของคุณใช้งานได้ แล้ว restart server

## API
- `GET /api/health` ตรวจสถานะเซิร์ฟเวอร์และการตั้งค่า
- `POST /api/chat` body: `{ "prompt": "...", "code": "..." }`
- `POST /api/review` body: `{ "code": "...", "language": "JavaScript" }`
- `POST /api/fix` body: `{ "code": "...", "issue": "...", "language": "JavaScript" }`

## ความปลอดภัยและข้อจำกัด
- API key อยู่ฝั่งเซิร์ฟเวอร์ใน `.env` เท่านั้น ห้ามใส่ในไฟล์หน้าเว็บหรือ commit ขึ้น Git
- มี rate limit เบื้องต้น 20 คำขอต่อนาทีต่อ IP
- โค้ดที่ส่งไปยัง AI จะถูกส่งให้ผู้ให้บริการ API ประมวลผล อย่าส่งรหัสผ่าน, token หรือข้อมูลลับ
- ระบบนี้ยังไม่รันโค้ดที่ผู้ใช้ส่งมา จึงเป็นการตรวจจาก AI ไม่ใช่การทดสอบ runtime หรือการรับรองความปลอดภัย
- ก่อน deploy จริง ควรเพิ่ม authentication, HTTPS, logging ที่ไม่เก็บ secrets, monitoring และ automated tests
